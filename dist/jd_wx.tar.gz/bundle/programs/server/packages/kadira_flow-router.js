(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var ReactiveVar = Package['reactive-var'].ReactiveVar;

/* Package-scope variables */
var FlowRouter, Router, Group, Route, FastRender;

(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/kadira:flow-router/server/router.js                                     //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
var Qs = Npm.require('qs');                                                         // 1
                                                                                    // 2
Router = function () {                                                              // 3
  this._routes = [];                                                                // 4
  this._routesMap = {};                                                             // 5
  this.subscriptions = Function.prototype;                                          // 6
};                                                                                  // 7
                                                                                    // 8
                                                                                    // 9
Router.prototype.route = function(path, options) {                                  // 10
  if (!/^\/.*/.test(path)) {                                                        // 11
    var message = "route's path must start with '/'";                               // 12
    throw new Error(message);                                                       // 13
  }                                                                                 // 14
                                                                                    // 15
  options = options || {};                                                          // 16
  var route = new Route(this, path, options);                                       // 17
  this._routes.push(route);                                                         // 18
                                                                                    // 19
  if (options.name) {                                                               // 20
    this._routesMap[options.name] = route;                                          // 21
  }                                                                                 // 22
                                                                                    // 23
  return route;                                                                     // 24
};                                                                                  // 25
                                                                                    // 26
Router.prototype.group = function(options) {                                        // 27
  return new Group(this, options);                                                  // 28
};                                                                                  // 29
                                                                                    // 30
Router.prototype.path = function(pathDef, fields, queryParams) {                    // 31
  if (this._routesMap[pathDef]) {                                                   // 32
    pathDef = this._routesMap[pathDef].path;                                        // 33
  }                                                                                 // 34
                                                                                    // 35
  fields = fields || {};                                                            // 36
  var regExp = /(:[\w\(\)\\\+\*\.\?]+)+/g;                                          // 37
  var path = pathDef.replace(regExp, function(key) {                                // 38
    var firstRegexpChar = key.indexOf("(");                                         // 39
    // get the content behind : and (\\d+/)                                         // 40
    key = key.substring(1, (firstRegexpChar > 0)? firstRegexpChar: undefined);      // 41
    // remove +?*                                                                   // 42
    key = key.replace(/[\+\*\?]+/g, "");                                            // 43
                                                                                    // 44
    return fields[key] || "";                                                       // 45
  });                                                                               // 46
                                                                                    // 47
  path = path.replace(/\/\/+/g, "/"); // Replace multiple slashes with single slash // 48
                                                                                    // 49
  // remove trailing slash                                                          // 50
  // but keep the root slash if it's the only one                                   // 51
  path = path.match(/^\/{1}$/) ? path: path.replace(/\/$/, "");                     // 52
                                                                                    // 53
  var strQueryParams = Qs.stringify(queryParams || {});                             // 54
  if(strQueryParams) {                                                              // 55
    path += "?" + strQueryParams;                                                   // 56
  }                                                                                 // 57
                                                                                    // 58
  return path;                                                                      // 59
};                                                                                  // 60
                                                                                    // 61
                                                                                    // 62
Router.prototype.go = function() {                                                  // 63
  // client only                                                                    // 64
};                                                                                  // 65
                                                                                    // 66
                                                                                    // 67
Router.prototype.current = function() {                                             // 68
  // client only                                                                    // 69
};                                                                                  // 70
                                                                                    // 71
                                                                                    // 72
Router.prototype.triggers = {                                                       // 73
  enter: function() {                                                               // 74
    // client only                                                                  // 75
  },                                                                                // 76
  exit: function() {                                                                // 77
    // client only                                                                  // 78
  }                                                                                 // 79
};                                                                                  // 80
                                                                                    // 81
Router.prototype.middleware = function() {                                          // 82
  // client only                                                                    // 83
};                                                                                  // 84
                                                                                    // 85
                                                                                    // 86
Router.prototype.getState = function() {                                            // 87
  // client only                                                                    // 88
};                                                                                  // 89
                                                                                    // 90
                                                                                    // 91
Router.prototype.getAllStates = function() {                                        // 92
  // client only                                                                    // 93
};                                                                                  // 94
                                                                                    // 95
                                                                                    // 96
Router.prototype.setState = function() {                                            // 97
  // client only                                                                    // 98
};                                                                                  // 99
                                                                                    // 100
                                                                                    // 101
Router.prototype.removeState = function() {                                         // 102
  // client only                                                                    // 103
};                                                                                  // 104
                                                                                    // 105
                                                                                    // 106
Router.prototype.clearStates = function() {                                         // 107
  // client only                                                                    // 108
};                                                                                  // 109
                                                                                    // 110
                                                                                    // 111
Router.prototype.ready = function() {                                               // 112
  // client only                                                                    // 113
};                                                                                  // 114
                                                                                    // 115
                                                                                    // 116
Router.prototype.initialize = function() {                                          // 117
  // client only                                                                    // 118
};                                                                                  // 119
                                                                                    // 120
Router.prototype.wait = function() {                                                // 121
  // client only                                                                    // 122
};                                                                                  // 123
                                                                                    // 124
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/kadira:flow-router/server/group.js                                      //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
Group = function(router, options) {                                                 // 1
  options = options || {};                                                          // 2
  this.prefix = options.prefix || '';                                               // 3
                                                                                    // 4
  this._router = router;                                                            // 5
};                                                                                  // 6
                                                                                    // 7
Group.prototype.route = function(path, options) {                                   // 8
  path = this.prefix + path;                                                        // 9
  return this._router.route(path, options);                                         // 10
};                                                                                  // 11
                                                                                    // 12
Group.prototype.group = function(options) {                                         // 13
  var group = new Group(this._router, options);                                     // 14
  group.parent = this;                                                              // 15
                                                                                    // 16
  return group;                                                                     // 17
};                                                                                  // 18
                                                                                    // 19
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/kadira:flow-router/server/route.js                                      //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
Route = function(router, path, options) {                                           // 1
  options = options || {};                                                          // 2
  this.options = options;                                                           // 3
                                                                                    // 4
  this.path = path;                                                                 // 5
  this.action = options.action || Function.prototype;                               // 6
  this.subscriptions = options.subscriptions || Function.prototype;                 // 7
  this._subsMap = {};                                                               // 8
};                                                                                  // 9
                                                                                    // 10
                                                                                    // 11
Route.prototype.register = function(name, sub, options) {                           // 12
  this._subsMap[name] = sub;                                                        // 13
};                                                                                  // 14
                                                                                    // 15
                                                                                    // 16
Route.prototype.subscription = function(name) {                                     // 17
  return this._subsMap[name];                                                       // 18
};                                                                                  // 19
                                                                                    // 20
                                                                                    // 21
Route.prototype.middleware = function(middleware) {                                 // 22
                                                                                    // 23
};                                                                                  // 24
                                                                                    // 25
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/kadira:flow-router/server/_init.js                                      //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
// Export Router Instance                                                           // 1
FlowRouter = new Router();                                                          // 2
FlowRouter.Router = Router;                                                         // 3
FlowRouter.Route = Route;                                                           // 4
                                                                                    // 5
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/kadira:flow-router/server/plugins/fast_render.js                        //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
if(!Package['meteorhacks:fast-render']) {                                           // 1
  return;                                                                           // 2
}                                                                                   // 3
                                                                                    // 4
FastRender = Package['meteorhacks:fast-render'].FastRender;                         // 5
                                                                                    // 6
// hack to run after eveything else on startup                                      // 7
Meteor.startup(function () {                                                        // 8
  Meteor.startup(function () {                                                      // 9
    setupFastRender();                                                              // 10
  });                                                                               // 11
});                                                                                 // 12
                                                                                    // 13
function setupFastRender () {                                                       // 14
  _.each(FlowRouter._routes, function (route) {                                     // 15
    FastRender.route(route.path, function (params, path) {                          // 16
      var self = this;                                                              // 17
                                                                                    // 18
      // anyone using Meteor.subscribe for something else?                          // 19
      var original = Meteor.subscribe;                                              // 20
      Meteor.subscribe = function () {                                              // 21
        return _.toArray(arguments);                                                // 22
      };                                                                            // 23
                                                                                    // 24
      route._subsMap = {};                                                          // 25
      FlowRouter.subscriptions.call(route, path);                                   // 26
      if(route.subscriptions) {                                                     // 27
        route.subscriptions(params);                                                // 28
      }                                                                             // 29
      _.each(route._subsMap, function (args) {                                      // 30
        self.subscribe.apply(self, args);                                           // 31
      });                                                                           // 32
                                                                                    // 33
      // restore Meteor.subscribe, ... on server side                               // 34
      Meteor.subscribe = original;                                                  // 35
    });                                                                             // 36
  });                                                                               // 37
}                                                                                   // 38
                                                                                    // 39
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kadira:flow-router'] = {
  FlowRouter: FlowRouter
};

})();

//# sourceMappingURL=kadira_flow-router.js.map
